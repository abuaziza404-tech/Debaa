# إصلاح GitHub Actions لبناء APK

## سبب الخطأ

الخطأ السابق كان:

```text
android-project.zip not found
```

يعني أن GitHub Actions لم يجد ملف المشروع المضغوط في جذر المستودع.

## الملفات المطلوبة داخل GitHub

ارفع الملفات بهذا الشكل:

```text
repo-root/
  أي-اسم-للمشروع.zip
  .github/
    workflows/
      build-apk-fixed.yml
```

هذا الإصدار لا يشترط اسم `android-project.zip`.
سيبحث تلقائيًا عن أول ملف `.zip` في المستودع ويبني منه APK.

## الأفضل

رغم أن الملف يقبل أي اسم، الأفضل أن تسمي ملف المشروع:

```text
android-project.zip
```

## تشغيل البناء

1. افتح المستودع في GitHub.
2. افتح تبويب Actions.
3. اختر:

```text
Build debug APK - auto find ZIP
```

4. اضغط Run workflow.
5. بعد النجاح حمّل APK من Artifacts باسم:

```text
A12-Recovery-Pro-Debug-APK
```
