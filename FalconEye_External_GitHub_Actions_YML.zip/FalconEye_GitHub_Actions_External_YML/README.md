# FalconEye External GitHub Actions YML

هذا ملف Workflow خارجي مستقل لنسخة FalconEye Gold AI Map UI Pro V5.

## الاستخدام

1. انسخ الملف:

```text
github_pages_external.yml
```

2. ضعه داخل مستودع GitHub في المسار:

```text
.github/workflows/github_pages_external.yml
```

3. ارفع المشروع إلى GitHub.

الملف سيقوم تلقائيًا بـ:

- فحص وجود `public/index.html` أو `docs/index.html`.
- فحص ملفات `gold_candidates.geojson` و `gold_model_config.json` عند وجودها.
- رفض TODO/FIXME أو مفاتيح API ظاهرة.
- نشر الموقع على GitHub Pages.

## ملاحظة

لا تضع ملف YAML في جذر المشروع إذا أردت أن يعمل تلقائيًا. GitHub Actions لا يقرأ workflows إلا من:

```text
.github/workflows/
```
