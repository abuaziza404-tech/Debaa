# Alpine Radar Direct GPS

حزمة جاهزة للرفع في **جذر المستودع مباشرة**.

## هل التطبيق مكتمل؟
نعم كمشروع جاهز للبناء:
- نسخة HTML/PWA في `html/`.
- مشروع Android APK في `android/`.
- Workflow جاهز في `.github/workflows/build-apk-and-pages.yml`.
- نسخة نصية من ملف YAML في `build-apk-and-pages.yml.txt`.

## ماذا يفعل workflow؟
- يبني APK debug.
- يرفع APK في Artifacts باسم `alpine-direct-gps-debug-apk`.
- ينشر نسخة HTML على GitHub Pages.

## طريقة الاستخدام على GitHub
1. افتح المستودع.
2. ارفع **محتويات هذه الحزمة إلى جذر المستودع**.
3. من Settings → Pages اختر Source: GitHub Actions.
4. ادفع إلى فرع `main` أو شغّل workflow يدويًا.
5. حمّل APK من Actions → Artifacts.

## بناء APK محليًا
```bash
cd android
gradle :app:assembleDebug
```

المخرج:
```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## تحسينات الدقة
- تشغيل مباشر GPS.
- `enableHighAccuracy: true`
- `maximumAge: 0`
- مؤشر جودة الدقة.
- Wake Lock في الويب وAndroid.
- WebView Android مع أذونات الموقع.
- زوم وطبقات لا تختفي عند الزوم العالي.

## تنبيه
الرادار آمن ويعرض نقاط المستخدم المحفوظة فقط. لا يحتوي على كشف شرطة أو رادارات حقيقية.
