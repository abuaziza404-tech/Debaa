# A12 Recovery Pro - GitHub Build بدون Android Studio وبدون فك المشروع

هذه الحزمة مصممة حتى ترفع ملف المشروع المضغوط كما هو إلى GitHub، ومعه ملف Workflow يقوم بفك المشروع داخل GitHub Actions ثم يبني APK تلقائيًا.

## الملفات المهمة

```text
android-project.zip
.github/workflows/build-apk-from-zip.yml
```

## طريقة الاستخدام من المتصفح أو الهاتف

1. افتح GitHub.
2. أنشئ Repository جديدًا.
3. ارفع هذين العنصرين إلى المستودع:
   - ملف `android-project.zip`
   - مجلد `.github/workflows/build-apk-from-zip.yml`
4. افتح تبويب Actions.
5. اختر:
   `Build APK from ZIP بدون فك المشروع`
6. اضغط:
   `Run workflow`
7. بعد انتهاء البناء، افتح آخر Run ثم حمّل Artifact باسم:
   `A12-Recovery-Pro-APK`

## ملاحظة مهمة

لا ترفع هذا الملف كملف ZIP واحد داخل GitHub فقط، لأن GitHub لن يرى ملف `.yml` إذا كان مخفيًا داخل ZIP. يجب أن يكون ملف `.github/workflows/build-apk-from-zip.yml` ظاهرًا داخل المستودع، بينما يبقى مشروع Android نفسه مضغوطًا في `android-project.zip`.

إذا كنت تستخدم الهاتف، أسهل طريقة هي رفع الملفين عبر GitHub web upload، أو استخدام تطبيق Termux مع أوامر git.
